Please see the details of the project description [here](https://www.udacity.com/course/viewer#!/c-ud837/l-4040108662/m-4606438835)
