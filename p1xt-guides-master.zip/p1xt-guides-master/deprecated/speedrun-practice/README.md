## Practice Speedrun
Topic specific practice, to build out a portfolio, gain additional experience in an area, or for a preset list of assignments to tackle for a hands-on boosting speedrun to drive your ability to the next level:

- [Algorithms and Data Structures](./algorithms.md)
- [Android](./android.md)
- [Frontend Web Development](./frontend-dev.md)
- [Fullstack Web Development](./fullstack-dev.md)
- [Game Development](./game-dev.md)