# Open Source Contributions Specialization

Pick one or more Open Source projects and contribute to them. Follow each project's contribution guidelines. Either tackle existing feature requests or bug reports on the project or propose, then once approved, add your own features.

| **Practice**                                                                                                                                                                    | **Status** | **Evidence** |
| :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | :--------: | :----------: |
| Study [This site](https://opensource.guide/how-to-contribute/)                                                                                                                  |            |
| Open Source Contribution                                                                                                                                                        |            |
| Open Source Contribution                                                                                                                                                        |            |
| Open Source Contribution                                                                                                                                                        |            |
| Open Source Contribution                                                                                                                                                        |            |
| Open Source Contribution                                                                                                                                                        |            |
| Open Source Contribution                                                                                                                                                        |            |
| Open Source Contribution                                                                                                                                                        |            |
| Open Source Contribution                                                                                                                                                        |            |
| Open Source Contribution                                                                                                                                                        |            |
| Open Source Contribution                                                                                                                                                        |            |
| Open Source Contribution                                                                                                                                                        |            |
| Open Source Contribution                                                                                                                                                        |            |
| **Capstone**                                                                                                                                                                    | **Status** | **Evidence** |
| Create a website highlighting what you learned and built during this specialization. Use this as an opportunity to create a portfolio of your projects, notes, blog posts, etc. |            |
